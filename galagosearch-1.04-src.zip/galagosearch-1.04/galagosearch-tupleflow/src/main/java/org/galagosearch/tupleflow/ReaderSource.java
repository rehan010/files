// BSD License (http://www.galagosearch.org/license)


package org.galagosearch.tupleflow;

/**
 *
 * @author trevor
 */
public interface ReaderSource<T> extends TypeReader<T>, ExNihiloSource<T> {
}
