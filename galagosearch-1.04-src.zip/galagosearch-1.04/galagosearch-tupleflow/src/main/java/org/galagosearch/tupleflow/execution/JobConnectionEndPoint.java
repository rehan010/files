// BSD License (http://www.galagosearch.org/license)
package org.galagosearch.tupleflow.execution;

/**
 *
 * @author trevor
 */
public class JobConnectionEndPoint {
}
