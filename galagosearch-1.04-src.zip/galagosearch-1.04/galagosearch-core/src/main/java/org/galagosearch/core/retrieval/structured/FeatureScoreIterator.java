// BSD License (http://www.galagosearch.org/license)
package org.galagosearch.core.retrieval.structured;

/**
 *
 * @author trevor
 */
public interface FeatureScoreIterator extends ScoreIterator {
}
