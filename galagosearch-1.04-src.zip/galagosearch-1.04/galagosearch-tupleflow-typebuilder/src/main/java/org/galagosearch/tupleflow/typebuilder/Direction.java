/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.galagosearch.tupleflow.typebuilder;

/**
 *
 * @author trevor
 */
public enum Direction {
    ASCENDING,
    DESCENDING
}

